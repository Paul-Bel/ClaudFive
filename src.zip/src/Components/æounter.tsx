import React from 'react';
import s from './Сounter.module.css'


type buttonProps = {
    num: number,
    limitation: {min: number, max: number}
}

export function Counter ({limitation, ...props}: buttonProps) {
    return ( <div className={props.num === limitation.max ? s.redFive : s.counter}>{props.num}</div>
    );
}


